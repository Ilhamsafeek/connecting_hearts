class ImageSliderModel{
  String _path;

  ImageSliderModel(this._path);

  String get path => _path;

  set path(String value) {
    _path = value;
  }

}