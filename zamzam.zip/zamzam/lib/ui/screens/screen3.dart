import 'package:flutter/material.dart';
// import 'package:youtube_clone/videoInfo.dart';

class Subscriptioins extends StatefulWidget {
  Subscriptioins({Key key}) : super(key: key);

  _SubscriptioinsState createState() => _SubscriptioinsState();
}

class _SubscriptioinsState extends State<Subscriptioins> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
