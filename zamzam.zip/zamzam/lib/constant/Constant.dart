String SPLASH_SCREEN='/SplashScreen',
PAY_TM='/Paytm',
SIGN_IN='/Signin';

